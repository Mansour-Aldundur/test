const pptxgen = require("pptxgenjs");
const fs = require("fs");

// Read the data
const data = JSON.parse(fs.readFileSync("chart_data.json", "utf8"));

// Create presentation
const pptx = new pptxgen();
pptx.layout = "LAYOUT_16x9";

// Color palette matching the original PDF
const COLORS = {
  success: "FFD966",
  onHold: "BDD7EE",
  inProcess: "4472C4",
  failure: "A6A6A6",
  headerBg: "003366",
  white: "FFFFFF",
  dark: "1F3864",
};

function formatNumber(num) {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// ================= SLIDE 1: Title Slide =================
const slide1 = pptx.addSlide();
slide1.background = { color: "002855" };
slide1.addText("هيئة الزكاة والضريبة والجمارك\nZakat, Tax and Customs Authority", {
  x: 6.5, y: 0.3, w: 3.2, h: 0.8,
  fontSize: 12, color: COLORS.white, align: "right", fontFace: "Arial",
});
slide1.addText("مشكلات التسجيل للسجل التجاري", {
  x: 0.5, y: 2.2, w: 9, h: 1,
  fontSize: 44, bold: true, color: COLORS.white, align: "center", fontFace: "Arial",
});
slide1.addText("إدارة تحسين وتطوير العمليات | العمليات", {
  x: 5, y: 4.8, w: 4.5, h: 0.4,
  fontSize: 10, color: COLORS.white, align: "right", fontFace: "Arial",
});

// ================= SLIDE 2: Total Update Cases =================
const slide2 = pptx.addSlide();
slide2.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide2.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4,
  fontSize: 24, bold: true, color: COLORS.white, align: "right", fontFace: "Arial",
});
slide2.addText("إجمالي حالات التحديث", {
  x: 0.5, y: 0.85, w: 9, h: 0.4,
  fontSize: 16, color: COLORS.dark, align: "center", fontFace: "Arial",
});

const totalsData = data.totals;
slide2.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: totalsData.months, values: totalsData.failure },
  { name: "In Process", labels: totalsData.months, values: totalsData.in_process },
  { name: "On Hold", labels: totalsData.months, values: totalsData.on_hold },
  { name: "Success", labels: totalsData.months, values: totalsData.success },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.8,
  barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.onHold, COLORS.success],
  showLegend: true, legendPos: "b",
  showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 7, dataLabelColor: "000000",
  catAxisLabelFontSize: 10, valAxisLabelFontSize: 9, valAxisMaxVal: 500000,
});

totalsData.months.forEach((month, idx) => {
  const xPos = 0.8 + idx * 1.0;
  slide2.addText(month, { x: xPos, y: 5.0, w: 0.9, h: 0.2, fontSize: 9, color: COLORS.dark, align: "center" });
  slide2.addText(formatNumber(totalsData.monthly_totals[idx]), { x: xPos, y: 5.2, w: 0.9, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 3: Deletion Cases =================
const slide3 = pptx.addSlide();
slide3.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide3.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4, fontSize: 24, bold: true, color: COLORS.white, align: "right",
});
slide3.addText("حالات الشطب", { x: 0.5, y: 0.85, w: 9, h: 0.4, fontSize: 16, color: COLORS.dark, align: "center" });

const deletionLabels = [], deletionFailure = [], deletionInProcess = [], deletionSuccess = [];
data.deletion.forEach((m) => {
  deletionLabels.push("NO\n" + m.month); deletionFailure.push(m.no.failure); deletionInProcess.push(m.no.in_process); deletionSuccess.push(m.no.success);
  deletionLabels.push("YES"); deletionFailure.push(m.yes.failure); deletionInProcess.push(m.yes.in_process); deletionSuccess.push(m.yes.success);
});

slide3.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: deletionLabels, values: deletionFailure },
  { name: "In Process", labels: deletionLabels, values: deletionInProcess },
  { name: "Success", labels: deletionLabels, values: deletionSuccess },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.6, barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.success],
  showLegend: true, legendPos: "r", showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 6,
});

data.deletion.forEach((m, idx) => {
  const xPos = 0.5 + idx * 1.0;
  slide3.addText(m.month, { x: xPos, y: 4.85, w: 1.0, h: 0.2, fontSize: 8, color: COLORS.dark, align: "center" });
  slide3.addText(formatNumber(m.total), { x: xPos, y: 5.05, w: 1.0, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 4: Ownership Transfer Cases =================
const slide4 = pptx.addSlide();
slide4.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide4.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4, fontSize: 24, bold: true, color: COLORS.white, align: "right",
});
slide4.addText("حالات نقل الملكية", { x: 0.5, y: 0.85, w: 9, h: 0.4, fontSize: 16, color: COLORS.dark, align: "center" });

const ownerLabels = [], ownerFailure = [], ownerInProcess = [], ownerOnHold = [], ownerSuccess = [];
data.ownership.forEach((m) => {
  ownerLabels.push("NO\n" + m.month); ownerFailure.push(m.no.failure); ownerInProcess.push(m.no.in_process); ownerOnHold.push(m.no.on_hold); ownerSuccess.push(m.no.success);
  ownerLabels.push("YES"); ownerFailure.push(m.yes.failure); ownerInProcess.push(m.yes.in_process); ownerOnHold.push(m.yes.on_hold); ownerSuccess.push(m.yes.success);
});

slide4.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: ownerLabels, values: ownerFailure },
  { name: "In Process", labels: ownerLabels, values: ownerInProcess },
  { name: "On Hold", labels: ownerLabels, values: ownerOnHold },
  { name: "Success", labels: ownerLabels, values: ownerSuccess },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.6, barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.onHold, COLORS.success],
  showLegend: true, legendPos: "r", showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 6,
});

data.ownership.forEach((m, idx) => {
  const xPos = 0.5 + idx * 1.0;
  slide4.addText(m.month, { x: xPos, y: 4.85, w: 1.0, h: 0.2, fontSize: 8, color: COLORS.dark, align: "center" });
  slide4.addText(formatNumber(m.total), { x: xPos, y: 5.05, w: 1.0, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 5: Entity Transformation Cases =================
const slide5 = pptx.addSlide();
slide5.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide5.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4, fontSize: 24, bold: true, color: COLORS.white, align: "right",
});
slide5.addText("حالات تحول الكيان", { x: 0.5, y: 0.85, w: 9, h: 0.4, fontSize: 16, color: COLORS.dark, align: "center" });

const entityLabels = [], entityFailure = [], entityInProcess = [], entityOnHold = [], entitySuccess = [];
data.entity.forEach((m) => {
  entityLabels.push("NO\n" + m.month); entityFailure.push(m.no.failure); entityInProcess.push(m.no.in_process); entityOnHold.push(m.no.on_hold); entitySuccess.push(m.no.success);
  entityLabels.push("YES"); entityFailure.push(m.yes.failure); entityInProcess.push(m.yes.in_process); entityOnHold.push(m.yes.on_hold); entitySuccess.push(m.yes.success);
});

slide5.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: entityLabels, values: entityFailure },
  { name: "In Process", labels: entityLabels, values: entityInProcess },
  { name: "On Hold", labels: entityLabels, values: entityOnHold },
  { name: "Success", labels: entityLabels, values: entitySuccess },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.6, barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.onHold, COLORS.success],
  showLegend: true, legendPos: "r", showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 6,
});

data.entity.forEach((m, idx) => {
  const xPos = 0.5 + idx * 1.1;
  slide5.addText(m.month, { x: xPos, y: 4.85, w: 1.0, h: 0.2, fontSize: 8, color: COLORS.dark, align: "center" });
  slide5.addText(formatNumber(m.total), { x: xPos, y: 5.05, w: 1.0, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 6: Thank You Slide =================
const slide6 = pptx.addSlide();
slide6.background = { color: "002855" };
slide6.addText("هيئة الزكاة والضريبة والجمارك\nZakat, Tax and Customs Authority", {
  x: 6.5, y: 0.3, w: 3.2, h: 0.8, fontSize: 12, color: COLORS.white, align: "right",
});
slide6.addText("شكراً", { x: 0.5, y: 2.2, w: 9, h: 1.2, fontSize: 72, bold: true, color: COLORS.white, align: "center" });
slide6.addText("عام | Public", { x: 3.5, y: 4.8, w: 3, h: 0.4, fontSize: 10, color: COLORS.white, align: "center" });

// Save presentation
const outputFile = process.argv[2] || "trade_data_report.pptx";
pptx.writeFile({ fileName: outputFile }).then(() => {
  console.log("✅ Presentation created: " + outputFile);
});
