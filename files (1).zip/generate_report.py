#!/usr/bin/env python3
"""
Trade Data PowerPoint Generator
================================
This script automatically generates a ZATCA-styled PowerPoint presentation
from four Excel data files:
1. المجاميع (Totals) - For total update cases
2. تفاصيل الشطب (Deletion Details) - For deletion cases
3. تفاصيل نقل الملكية (Ownership Transfer Details) - For ownership transfer cases
4. تحول الكيان (Entity Transformation) - For entity transformation cases

Usage:
    python generate_report.py [--output OUTPUT_NAME]
    
Requirements:
    - Python packages: pandas, openpyxl
    - Node.js packages: pptxgenjs (install globally: npm install -g pptxgenjs)
"""

import pandas as pd
import json
import subprocess
import os
import sys
import argparse
from pathlib import Path
from datetime import datetime

# Configuration
EXCEL_FILES = {
    'totals': 'المجاميع1.xlsx',
    'deletion': 'تفاصيل الشطب 1.xlsx',
    'ownership': 'تفاصيل نقل الملكية1.xlsx',
    'entity': '1تحول الكيان.xlsx'
}

# Alternative English names (fallback)
EXCEL_FILES_EN = {
    'totals': 'totals.xlsx',
    'deletion': 'deletion_details.xlsx',
    'ownership': 'ownership_transfer.xlsx',
    'entity': 'entity_transformation.xlsx'
}

MONTH_ORDER = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
ENTITY_MONTHS = ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']


def find_excel_file(file_key, data_dir):
    """Find Excel file using Arabic or English names."""
    # Try Arabic name first
    arabic_path = data_dir / EXCEL_FILES[file_key]
    if arabic_path.exists():
        return arabic_path
    
    # Try English name
    english_path = data_dir / EXCEL_FILES_EN[file_key]
    if english_path.exists():
        return english_path
    
    # Try to find any matching file
    for f in data_dir.glob('*.xlsx'):
        fname = f.name.lower()
        if file_key == 'totals' and ('مجاميع' in f.name or 'total' in fname):
            return f
        elif file_key == 'deletion' and ('شطب' in f.name or 'delet' in fname):
            return f
        elif file_key == 'ownership' and ('ملكية' in f.name or 'owner' in fname):
            return f
        elif file_key == 'entity' and ('كيان' in f.name or 'entity' in fname):
            return f
    
    raise FileNotFoundError(f"Could not find {file_key} Excel file in {data_dir}")


def process_totals(df):
    """Process totals data for the first chart."""
    pivot = df.groupby(['Month', 'status'])['Count_of_cr_numbers'].sum().unstack(fill_value=0)
    pivot = pivot.reindex(MONTH_ORDER).fillna(0)
    
    for col in ['Failure', 'In Process', 'On Hold', 'Success']:
        if col not in pivot.columns:
            pivot[col] = 0
    
    data = {
        'months': list(pivot.index),
        'failure': [int(x) for x in pivot['Failure'].tolist()],
        'in_process': [int(x) for x in pivot['In Process'].tolist()],
        'on_hold': [int(x) for x in pivot['On Hold'].tolist()],
        'success': [int(x) for x in pivot['Success'].tolist()]
    }
    
    data['monthly_totals'] = [
        data['failure'][i] + data['in_process'][i] + 
        data['on_hold'][i] + data['success'][i]
        for i in range(len(data['months']))
    ]
    
    return data


def process_yes_no_data(df, updated_col, months=MONTH_ORDER, has_on_hold=False):
    """Process data with YES/NO grouping."""
    agg = df.groupby(['Month', updated_col, 'status']).size().reset_index(name='count')
    pivot = agg.pivot_table(
        index=['Month', updated_col], 
        columns='status', 
        values='count', 
        fill_value=0
    ).reset_index()
    
    status_cols = ['Failure', 'In Process', 'Success']
    if has_on_hold:
        status_cols.append('On Hold')
    
    for col in status_cols:
        if col not in pivot.columns:
            pivot[col] = 0
    
    pivot['Month'] = pd.Categorical(pivot['Month'], categories=months, ordered=True)
    pivot = pivot.sort_values(['Month', updated_col])
    
    result = []
    for month in months:
        month_data = pivot[pivot['Month'] == month]
        if len(month_data) > 0:
            no_row = month_data[month_data[updated_col] == 'NO']
            yes_row = month_data[month_data[updated_col] == 'YES']
            
            no_data = {'failure': 0, 'in_process': 0, 'success': 0}
            yes_data = {'failure': 0, 'in_process': 0, 'success': 0}
            
            if has_on_hold:
                no_data['on_hold'] = 0
                yes_data['on_hold'] = 0
            
            if len(no_row) > 0:
                no_data['failure'] = int(no_row['Failure'].values[0])
                no_data['in_process'] = int(no_row['In Process'].values[0]) if 'In Process' in no_row.columns else 0
                no_data['success'] = int(no_row['Success'].values[0])
                if has_on_hold:
                    no_data['on_hold'] = int(no_row['On Hold'].values[0]) if 'On Hold' in no_row.columns else 0
            
            if len(yes_row) > 0:
                yes_data['failure'] = int(yes_row['Failure'].values[0])
                yes_data['in_process'] = int(yes_row['In Process'].values[0]) if 'In Process' in yes_row.columns else 0
                yes_data['success'] = int(yes_row['Success'].values[0])
                if has_on_hold:
                    yes_data['on_hold'] = int(yes_row['On Hold'].values[0]) if 'On Hold' in yes_row.columns else 0
            
            total = sum(no_data.values()) + sum(yes_data.values())
            result.append({
                'month': month,
                'no': no_data,
                'yes': yes_data,
                'total': total
            })
    
    return result


def generate_js_script():
    """Generate the JavaScript code for PowerPoint creation."""
    return '''const pptxgen = require("pptxgenjs");
const fs = require("fs");

// Read the data
const data = JSON.parse(fs.readFileSync("chart_data.json", "utf8"));

// Create presentation
const pptx = new pptxgen();
pptx.layout = "LAYOUT_16x9";

// Color palette matching the original PDF
const COLORS = {
  success: "FFD966",
  onHold: "BDD7EE",
  inProcess: "4472C4",
  failure: "A6A6A6",
  headerBg: "003366",
  white: "FFFFFF",
  dark: "1F3864",
};

function formatNumber(num) {
  return num.toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ",");
}

// ================= SLIDE 1: Title Slide =================
const slide1 = pptx.addSlide();
slide1.background = { color: "002855" };
slide1.addText("هيئة الزكاة والضريبة والجمارك\\nZakat, Tax and Customs Authority", {
  x: 6.5, y: 0.3, w: 3.2, h: 0.8,
  fontSize: 12, color: COLORS.white, align: "right", fontFace: "Arial",
});
slide1.addText("مشكلات التسجيل للسجل التجاري", {
  x: 0.5, y: 2.2, w: 9, h: 1,
  fontSize: 44, bold: true, color: COLORS.white, align: "center", fontFace: "Arial",
});
slide1.addText("إدارة تحسين وتطوير العمليات | العمليات", {
  x: 5, y: 4.8, w: 4.5, h: 0.4,
  fontSize: 10, color: COLORS.white, align: "right", fontFace: "Arial",
});

// ================= SLIDE 2: Total Update Cases =================
const slide2 = pptx.addSlide();
slide2.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide2.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4,
  fontSize: 24, bold: true, color: COLORS.white, align: "right", fontFace: "Arial",
});
slide2.addText("إجمالي حالات التحديث", {
  x: 0.5, y: 0.85, w: 9, h: 0.4,
  fontSize: 16, color: COLORS.dark, align: "center", fontFace: "Arial",
});

const totalsData = data.totals;
slide2.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: totalsData.months, values: totalsData.failure },
  { name: "In Process", labels: totalsData.months, values: totalsData.in_process },
  { name: "On Hold", labels: totalsData.months, values: totalsData.on_hold },
  { name: "Success", labels: totalsData.months, values: totalsData.success },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.8,
  barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.onHold, COLORS.success],
  showLegend: true, legendPos: "b",
  showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 7, dataLabelColor: "000000",
  catAxisLabelFontSize: 10, valAxisLabelFontSize: 9, valAxisMaxVal: 500000,
});

totalsData.months.forEach((month, idx) => {
  const xPos = 0.8 + idx * 1.0;
  slide2.addText(month, { x: xPos, y: 5.0, w: 0.9, h: 0.2, fontSize: 9, color: COLORS.dark, align: "center" });
  slide2.addText(formatNumber(totalsData.monthly_totals[idx]), { x: xPos, y: 5.2, w: 0.9, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 3: Deletion Cases =================
const slide3 = pptx.addSlide();
slide3.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide3.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4, fontSize: 24, bold: true, color: COLORS.white, align: "right",
});
slide3.addText("حالات الشطب", { x: 0.5, y: 0.85, w: 9, h: 0.4, fontSize: 16, color: COLORS.dark, align: "center" });

const deletionLabels = [], deletionFailure = [], deletionInProcess = [], deletionSuccess = [];
data.deletion.forEach((m) => {
  deletionLabels.push("NO\\n" + m.month); deletionFailure.push(m.no.failure); deletionInProcess.push(m.no.in_process); deletionSuccess.push(m.no.success);
  deletionLabels.push("YES"); deletionFailure.push(m.yes.failure); deletionInProcess.push(m.yes.in_process); deletionSuccess.push(m.yes.success);
});

slide3.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: deletionLabels, values: deletionFailure },
  { name: "In Process", labels: deletionLabels, values: deletionInProcess },
  { name: "Success", labels: deletionLabels, values: deletionSuccess },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.6, barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.success],
  showLegend: true, legendPos: "r", showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 6,
});

data.deletion.forEach((m, idx) => {
  const xPos = 0.5 + idx * 1.0;
  slide3.addText(m.month, { x: xPos, y: 4.85, w: 1.0, h: 0.2, fontSize: 8, color: COLORS.dark, align: "center" });
  slide3.addText(formatNumber(m.total), { x: xPos, y: 5.05, w: 1.0, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 4: Ownership Transfer Cases =================
const slide4 = pptx.addSlide();
slide4.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide4.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4, fontSize: 24, bold: true, color: COLORS.white, align: "right",
});
slide4.addText("حالات نقل الملكية", { x: 0.5, y: 0.85, w: 9, h: 0.4, fontSize: 16, color: COLORS.dark, align: "center" });

const ownerLabels = [], ownerFailure = [], ownerInProcess = [], ownerOnHold = [], ownerSuccess = [];
data.ownership.forEach((m) => {
  ownerLabels.push("NO\\n" + m.month); ownerFailure.push(m.no.failure); ownerInProcess.push(m.no.in_process); ownerOnHold.push(m.no.on_hold); ownerSuccess.push(m.no.success);
  ownerLabels.push("YES"); ownerFailure.push(m.yes.failure); ownerInProcess.push(m.yes.in_process); ownerOnHold.push(m.yes.on_hold); ownerSuccess.push(m.yes.success);
});

slide4.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: ownerLabels, values: ownerFailure },
  { name: "In Process", labels: ownerLabels, values: ownerInProcess },
  { name: "On Hold", labels: ownerLabels, values: ownerOnHold },
  { name: "Success", labels: ownerLabels, values: ownerSuccess },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.6, barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.onHold, COLORS.success],
  showLegend: true, legendPos: "r", showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 6,
});

data.ownership.forEach((m, idx) => {
  const xPos = 0.5 + idx * 1.0;
  slide4.addText(m.month, { x: xPos, y: 4.85, w: 1.0, h: 0.2, fontSize: 8, color: COLORS.dark, align: "center" });
  slide4.addText(formatNumber(m.total), { x: xPos, y: 5.05, w: 1.0, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 5: Entity Transformation Cases =================
const slide5 = pptx.addSlide();
slide5.addShape(pptx.shapes.RECTANGLE, { x: 0, y: 0, w: 10, h: 0.7, fill: { color: COLORS.headerBg } });
slide5.addText("حالة عكس حالات تحديث السجلات", {
  x: 0.3, y: 0.15, w: 9.4, h: 0.4, fontSize: 24, bold: true, color: COLORS.white, align: "right",
});
slide5.addText("حالات تحول الكيان", { x: 0.5, y: 0.85, w: 9, h: 0.4, fontSize: 16, color: COLORS.dark, align: "center" });

const entityLabels = [], entityFailure = [], entityInProcess = [], entityOnHold = [], entitySuccess = [];
data.entity.forEach((m) => {
  entityLabels.push("NO\\n" + m.month); entityFailure.push(m.no.failure); entityInProcess.push(m.no.in_process); entityOnHold.push(m.no.on_hold); entitySuccess.push(m.no.success);
  entityLabels.push("YES"); entityFailure.push(m.yes.failure); entityInProcess.push(m.yes.in_process); entityOnHold.push(m.yes.on_hold); entitySuccess.push(m.yes.success);
});

slide5.addChart(pptx.charts.BAR, [
  { name: "Failure", labels: entityLabels, values: entityFailure },
  { name: "In Process", labels: entityLabels, values: entityInProcess },
  { name: "On Hold", labels: entityLabels, values: entityOnHold },
  { name: "Success", labels: entityLabels, values: entitySuccess },
], {
  x: 0.3, y: 1.3, w: 9.4, h: 3.6, barDir: "col", barGrouping: "stacked",
  chartColors: [COLORS.failure, COLORS.inProcess, COLORS.onHold, COLORS.success],
  showLegend: true, legendPos: "r", showValue: true, dataLabelPosition: "ctr", dataLabelFontSize: 6,
});

data.entity.forEach((m, idx) => {
  const xPos = 0.5 + idx * 1.1;
  slide5.addText(m.month, { x: xPos, y: 4.85, w: 1.0, h: 0.2, fontSize: 8, color: COLORS.dark, align: "center" });
  slide5.addText(formatNumber(m.total), { x: xPos, y: 5.05, w: 1.0, h: 0.2, fontSize: 10, bold: true, color: COLORS.dark, align: "center" });
});

// ================= SLIDE 6: Thank You Slide =================
const slide6 = pptx.addSlide();
slide6.background = { color: "002855" };
slide6.addText("هيئة الزكاة والضريبة والجمارك\\nZakat, Tax and Customs Authority", {
  x: 6.5, y: 0.3, w: 3.2, h: 0.8, fontSize: 12, color: COLORS.white, align: "right",
});
slide6.addText("شكراً", { x: 0.5, y: 2.2, w: 9, h: 1.2, fontSize: 72, bold: true, color: COLORS.white, align: "center" });
slide6.addText("عام | Public", { x: 3.5, y: 4.8, w: 3, h: 0.4, fontSize: 10, color: COLORS.white, align: "center" });

// Save presentation
const outputFile = process.argv[2] || "trade_data_report.pptx";
pptx.writeFile({ fileName: outputFile }).then(() => {
  console.log("✅ Presentation created: " + outputFile);
});
'''


def main():
    parser = argparse.ArgumentParser(description='Generate ZATCA Trade Data PowerPoint Report')
    parser.add_argument('--data-dir', '-d', type=str, default='.', 
                       help='Directory containing the Excel files')
    parser.add_argument('--output', '-o', type=str, default=None,
                       help='Output PowerPoint filename (default: trade_data_report_YYYYMMDD.pptx)')
    args = parser.parse_args()
    
    data_dir = Path(args.data_dir)
    work_dir = Path.cwd()
    
    # Generate output filename with date
    if args.output:
        output_name = args.output if args.output.endswith('.pptx') else f"{args.output}.pptx"
    else:
        date_str = datetime.now().strftime('%Y%m%d')
        output_name = f"trade_data_report_{date_str}.pptx"
    
    print("=" * 60)
    print("ZATCA Trade Data Report Generator")
    print("=" * 60)
    print(f"Data directory: {data_dir.absolute()}")
    print(f"Output file: {output_name}")
    print()
    
    # Step 1: Find and read Excel files
    print("📊 Reading Excel files...")
    try:
        totals_path = find_excel_file('totals', data_dir)
        deletion_path = find_excel_file('deletion', data_dir)
        ownership_path = find_excel_file('ownership', data_dir)
        entity_path = find_excel_file('entity', data_dir)
        
        print(f"  ✓ Totals: {totals_path.name}")
        print(f"  ✓ Deletion: {deletion_path.name}")
        print(f"  ✓ Ownership: {ownership_path.name}")
        print(f"  ✓ Entity: {entity_path.name}")
        
        totals_df = pd.read_excel(totals_path)
        deletion_df = pd.read_excel(deletion_path)
        ownership_df = pd.read_excel(ownership_path)
        entity_df = pd.read_excel(entity_path)
        
    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        print("\nPlease ensure the following Excel files are in the data directory:")
        for key, name in EXCEL_FILES.items():
            print(f"  - {name}")
        sys.exit(1)
    
    # Step 2: Process data
    print("\n🔄 Processing data...")
    
    totals_data = process_totals(totals_df)
    print(f"  ✓ Total Update Cases: {len(totals_data['months'])} months")
    
    deletion_data = process_yes_no_data(deletion_df, 'Updated_CANCELLATION', has_on_hold=False)
    print(f"  ✓ Deletion Cases: {len(deletion_data)} months")
    
    ownership_data = process_yes_no_data(ownership_df, 'Updated', has_on_hold=True)
    print(f"  ✓ Ownership Transfer Cases: {len(ownership_data)} months")
    
    entity_df_filtered = entity_df[entity_df['Month'].isin(ENTITY_MONTHS)]
    entity_data = process_yes_no_data(entity_df_filtered, 'Updated', months=ENTITY_MONTHS, has_on_hold=True)
    print(f"  ✓ Entity Transformation Cases: {len(entity_data)} months")
    
    # Step 3: Save JSON data
    all_data = {
        'totals': totals_data,
        'deletion': deletion_data,
        'ownership': ownership_data,
        'entity': entity_data
    }
    
    json_path = work_dir / 'chart_data.json'
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)
    print(f"\n💾 Data saved to: {json_path}")
    
    # Step 4: Generate JavaScript and run it
    print("\n📝 Generating PowerPoint...")
    
    js_path = work_dir / 'generate_pptx.js'
    with open(js_path, 'w', encoding='utf-8') as f:
        f.write(generate_js_script())
    
    # Run Node.js script
    try:
        result = subprocess.run(
            ['node', str(js_path), output_name],
            capture_output=True,
            text=True,
            cwd=str(work_dir),
            env={**os.environ, 'NODE_PATH': subprocess.run(
                ['npm', 'root', '-g'], capture_output=True, text=True
            ).stdout.strip()}
        )
        
        if result.returncode == 0:
            print(f"\n✅ SUCCESS! Report generated: {output_name}")
            print(f"\n📁 Output file: {(work_dir / output_name).absolute()}")
        else:
            print(f"\n❌ Error generating PowerPoint:")
            print(result.stderr)
            sys.exit(1)
            
    except FileNotFoundError:
        print("\n❌ Error: Node.js is not installed or not in PATH")
        print("Please install Node.js and pptxgenjs:")
        print("  1. Install Node.js from https://nodejs.org/")
        print("  2. Run: npm install -g pptxgenjs")
        sys.exit(1)
    
    # Cleanup
    os.remove(js_path)
    print("\n" + "=" * 60)
    print("Report generation complete!")
    print("=" * 60)


if __name__ == '__main__':
    main()
